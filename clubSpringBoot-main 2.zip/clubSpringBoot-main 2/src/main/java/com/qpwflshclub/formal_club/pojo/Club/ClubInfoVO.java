package com.qpwflshclub.formal_club.pojo.Club;

import lombok.Data;

@Data
public class ClubInfoVO {
    private String clubName;
    private String clubItem;
    private String president;
    private String vicePresident;
    private String teacher;
    private String clubDescription;
    private Integer videoLike;
    private String video;

    public void setClubDescription(String clubDescription) {
        this.clubDescription = clubDescription;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public void setClubItem(String clubItem) {
        this.clubItem = clubItem;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public void setVideoLike(Integer videoLike) {
        this.videoLike = videoLike;
    }

    public void setPresident(String president) {
        this.president = president;
    }

    public void setVicePresident(String vicePresident) {
        this.vicePresident = vicePresident;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
}
